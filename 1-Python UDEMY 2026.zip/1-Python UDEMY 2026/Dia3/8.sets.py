m_set = ([1,2,3,4,5,])  
print(m_set)

s1 = {1,2,3}    
s2 = {4,5,6}
s3 = s1.union(s2)
print(s3)   
